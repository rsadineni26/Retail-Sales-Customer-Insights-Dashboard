CREATE DATABASE retail_db;
USE retail_db;

-- Customers
CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100),
    region VARCHAR(50),
    join_date DATE
);

-- Products
CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100),
    category VARCHAR(50)
);

-- Marketing Spend
CREATE TABLE marketing_spend (
    month DATE,
    channel VARCHAR(50),
    budget INT
);

-- Merged Sales
CREATE TABLE sales_data (
    sale_id INT PRIMARY KEY,
    customer_id INT,
    product_id INT,
    quantity INT,
    sale_date DATE,
    unit_price FLOAT,
    total_price FLOAT,
    customer_name VARCHAR(100),
    region VARCHAR(50),
    join_date DATE,
    product_name VARCHAR(100),
    category VARCHAR(50)
);
