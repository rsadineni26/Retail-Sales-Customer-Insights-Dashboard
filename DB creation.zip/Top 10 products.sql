SELECT product_name, SUM(quantity) AS total_units
FROM sales_data
GROUP BY product_name
ORDER BY total_units DESC
LIMIT 10
;
