SELECT region, SUM(total_price) AS revenue
FROM sales_data
GROUP BY region;
