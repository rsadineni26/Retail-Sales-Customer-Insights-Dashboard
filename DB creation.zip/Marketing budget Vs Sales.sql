SELECT 
    DATE_FORMAT(s.sale_date, '%Y-%m') AS month,
    SUM(s.total_price) AS sales_revenue,
    SUM(m.budget) AS marketing_spend
FROM sales_data s
JOIN marketing_spend m ON DATE_FORMAT(s.sale_date, '%Y-%m') = DATE_FORMAT(m.month, '%Y-%m')
GROUP BY DATE_FORMAT(s.sale_date, '%Y-%m');
