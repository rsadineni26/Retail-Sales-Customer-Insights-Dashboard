SELECT DATE_FORMAT(sale_date, '%Y-%m') AS month, SUM(total_price) AS revenue
FROM sales_data
GROUP BY month
ORDER BY month;
